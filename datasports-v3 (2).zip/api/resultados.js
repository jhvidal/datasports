const API_KEY  = '36066af4b19817b9908089edae63b4f2';
const API_BASE = 'https://v3.football.api-sports.io';

export default async function handler(req, res) {
  const params = req.query;
  const path = params.path || 'status';
  
  const apiParams = Object.entries(params)
    .filter(([k]) => k !== 'path')
    .map(([k, v]) => `${encodeURIComponent(k)}=${encodeURIComponent(v)}`)
    .join('&');

  const url = `${API_BASE}/${path}${apiParams ? '?' + apiParams : ''}`;

  try {
    const response = await fetch(url, {
      headers: {
        'x-apisports-key': API_KEY,
        'x-rapidapi-key': API_KEY,
        'x-rapidapi-host': 'v3.football.api-sports.io',
      }
    });
    const data = await response.json();
    res.setHeader('Access-Control-Allow-Origin', '*');
    res.setHeader('Cache-Control', 'no-store, no-cache, must-revalidate');
    res.status(200).json(data);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
}
